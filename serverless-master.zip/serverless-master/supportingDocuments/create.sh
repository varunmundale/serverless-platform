#!/bin/sh
cd $HOME
mkdir -p Services/Developer
mkdir -p Services/Configuration
mkdir -p Services/System