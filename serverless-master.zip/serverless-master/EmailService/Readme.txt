All inside JSONObject "parameters"

1. type = send
2. smtp_host (Ex- "students.iiit.ac.in")
3. username (Same as email_id)
4. password
5. sender (Mail ID)
6. receiver (Mail ID)
7. subject
8. message

returns status, message