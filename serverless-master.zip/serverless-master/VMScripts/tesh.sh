bash SingleMachineSetup.sh $1 $2 $3 $4 | tail -1 | tail -1
