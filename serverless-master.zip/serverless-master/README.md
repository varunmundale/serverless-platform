# Serverless Architecture
Platform for developers to deploy their services.

For Platform Buyers:
It enables Platform buyers to setup a distributed platform

For Developers:
It enables deployment of services without worring about scalability and availability of servers
